<?php
namespace CodexShaper\Dumper\Contracts;

interface Dumper
{
    public function dump();
    public function restore();
}
